import 'package:flutter/material.dart';

class CrossAxisRowPage extends StatelessWidget {
  const CrossAxisRowPage({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text("Row: CrossAxisAlignment.start",
              style: TextStyle(fontWeight: FontWeight.bold)),
          Container(
            color: Colors.grey.shade300,
            height: 150,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [largeRed, midYellow, smallGreen],
            ),
          ),
          const Divider(),
          const Text("Row: CrossAxisAlignment.end",
              style: TextStyle(fontWeight: FontWeight.bold)),
          Container(
            color: Colors.grey.shade300,
            height: 150,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [largeRed, midYellow, smallGreen],
            ),
          ),
          const Divider(),
          const Text("Row: CrossAxisAlignment.center",
              style: TextStyle(fontWeight: FontWeight.bold)),
          Container(
            color: Colors.grey.shade300,
            height: 150,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [largeRed, midYellow, smallGreen],
            ),
          ),
          const Divider(),
          const Text("Row: CrossAxisAlignment.stretch",
              style: TextStyle(fontWeight: FontWeight.bold)),
          Container(
            color: Colors.grey.shade300,
            height: 150,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [largeRed, midYellow, smallGreen],
            ),
          ),
          const Divider(),
          const Text("Row: CrossAxisAlignment.baseline",
              style: TextStyle(fontWeight: FontWeight.bold)),
          Container(
            color: Colors.grey.shade300,
            height: 120,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: const [
                Text("BIG", style: TextStyle(fontSize: 40, color: Colors.red)),
                Text("Mid",
                    style: TextStyle(fontSize: 25, color: Colors.yellow)),
                Text("Small",
                    style: TextStyle(fontSize: 15, color: Colors.green)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

Widget largeRed = Container(width: 100, height: 100, color: Colors.red);
Widget midYellow = Container(width: 70, height: 70, color: Colors.yellow);
Widget smallGreen = Container(width: 40, height: 40, color: Colors.green);
