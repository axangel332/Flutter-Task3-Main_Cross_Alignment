import 'package:flutter/material.dart';

class MainAxisPage extends StatelessWidget {
  const MainAxisPage({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text("Row: MainAxisAlignment.center",
              style: TextStyle(fontWeight: FontWeight.bold)),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [largeRed, midYellow, smallGreen],
          ),
          const Divider(),
          const Text("Row: MainAxisAlignment.spaceAround",
              style: TextStyle(fontWeight: FontWeight.bold)),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [largeRed, midYellow, smallGreen],
          ),
          const Divider(),
          const Text("Row: MainAxisAlignment.spaceBetween",
              style: TextStyle(fontWeight: FontWeight.bold)),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [largeRed, midYellow, smallGreen],
          ),
          const Divider(),
          const Text("Row: MainAxisAlignment.spaceEvenly",
              style: TextStyle(fontWeight: FontWeight.bold)),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [largeRed, midYellow, smallGreen],
          ),
          const Divider(),
          const Text("Row: MainAxisAlignment.start",
              style: TextStyle(fontWeight: FontWeight.bold)),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [largeRed, midYellow, smallGreen],
          ),
          const Divider(),
          const Text("Row: MainAxisAlignment.end",
              style: TextStyle(fontWeight: FontWeight.bold)),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [largeRed, midYellow, smallGreen],
          ),
          const Divider(height: 30, thickness: 2),
          const Text("Column: MainAxisAlignment.center",
              style: TextStyle(fontWeight: FontWeight.bold)),
          Container(
            height: 250,
            color: Colors.grey.shade300,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [largeRed, midYellow, smallGreen],
            ),
          ),
          const Divider(),
          const Text("Column: MainAxisAlignment.spaceEvenly",
              style: TextStyle(fontWeight: FontWeight.bold)),
          Container(
            height: 250,
            color: Colors.grey.shade300,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [largeRed, midYellow, smallGreen],
            ),
          ),
        ],
      ),
    );
  }
}

Widget largeRed = Container(width: 100, height: 100, color: Colors.red);
Widget midYellow = Container(width: 70, height: 70, color: Colors.yellow);
Widget smallGreen = Container(width: 40, height: 40, color: Colors.green);
