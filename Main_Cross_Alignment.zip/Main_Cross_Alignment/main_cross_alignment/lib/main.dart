import 'package:flutter/material.dart';
import 'package:main_cross_alignment/CrossAxisColumnPage.dart';
import 'package:main_cross_alignment/CrossAxisRowPage.dart';
import 'package:main_cross_alignment/MainAxisPage.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _selectedIndex = 0;

  final List<Widget> _pages = [
    const MainAxisPage(),
    const CrossAxisRowPage(),
    const CrossAxisColumnPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Sumalan Appbar"),
        centerTitle: true,
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.blue,
        onTap: (index) => setState(() => _selectedIndex = index),
        items: const [
          BottomNavigationBarItem(
              icon: Icon(Icons.align_horizontal_center), label: "Main Axis"),
          BottomNavigationBarItem(
              icon: Icon(Icons.align_vertical_bottom), label: "Row Cross Axis"),
          BottomNavigationBarItem(
              icon: Icon(Icons.view_column), label: "Column Cross Axis"),
        ],
      ),
    );
  }
}

Widget largeRed = Container(width: 100, height: 100, color: Colors.red);
Widget midYellow = Container(width: 70, height: 70, color: Colors.yellow);
Widget smallGreen = Container(width: 40, height: 40, color: Colors.green);
