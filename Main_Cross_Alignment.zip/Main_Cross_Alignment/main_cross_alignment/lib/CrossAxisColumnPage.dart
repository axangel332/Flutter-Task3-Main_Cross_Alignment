import 'package:flutter/material.dart';

class CrossAxisColumnPage extends StatelessWidget {
  const CrossAxisColumnPage({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text("Column: CrossAxisAlignment.start",
              style: TextStyle(fontWeight: FontWeight.bold)),
          Container(
            height: 250,
            color: Colors.grey.shade300,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [largeRed, midYellow, smallGreen],
            ),
          ),
          const Divider(),
          const Text("Column: CrossAxisAlignment.center",
              style: TextStyle(fontWeight: FontWeight.bold)),
          Container(
            height: 250,
            color: Colors.grey.shade300,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [largeRed, midYellow, smallGreen],
            ),
          ),
          const Divider(),
          const Text("Column: CrossAxisAlignment.end",
              style: TextStyle(fontWeight: FontWeight.bold)),
          Container(
            height: 250,
            color: Colors.grey.shade300,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [largeRed, midYellow, smallGreen],
            ),
          ),
          const Divider(),
          const Text("Column: CrossAxisAlignment.stretch",
              style: TextStyle(fontWeight: FontWeight.bold)),
          Container(
            height: 250,
            color: Colors.grey.shade300,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [largeRed, midYellow, smallGreen],
            ),
          ),
        ],
      ),
    );
  }
}

Widget largeRed = Container(width: 100, height: 100, color: Colors.red);
Widget midYellow = Container(width: 70, height: 70, color: Colors.yellow);
Widget smallGreen = Container(width: 40, height: 40, color: Colors.green);
