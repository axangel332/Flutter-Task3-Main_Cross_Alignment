package com.example.main_cross_alignment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
